/* ============================================================
   voz.js
   ------------------------------------------------------------
   Todo lo que tiene que ver con el oído del usuario:
     1. hablar(texto)  — el navegador lee un texto en voz alta
     2. Los comandos de voz — el usuario le habla a la app
     3. vibrar() — el aviso que se siente, no se oye

   Este archivo es el corazón de TMAp. Una persona ciega no ve
   la pantalla: todo lo que la app "muestra" tiene que pasar
   también por aquí.
   ============================================================ */


/* ── 1. ESCOGER UNA VOZ EN ESPAÑOL ────────────────────────
   El navegador tarda unos milisegundos en cargar la lista de
   voces, por eso se pide dos veces: ahora y cuando avise.    */

var vozES = null;

function cargarVoces(){
  if (!('speechSynthesis' in window)) return;
  var voces = speechSynthesis.getVoices();
  if (!voces.length) return;

  vozES = voces.filter(function (v) { return /^es[-_]CO/i.test(v.lang); })[0]   // Colombia
       || voces.filter(function (v) { return /^es[-_](419|MX|US)/i.test(v.lang); })[0]
       || voces.filter(function (v) { return /^es/i.test(v.lang); })[0]
       || null;
}

if ('speechSynthesis' in window) {
  speechSynthesis.onvoiceschanged = cargarVoces;
  cargarVoces();
  setTimeout(cargarVoces, 500);
}


/* ── 2. LA FUNCIÓN MÁS USADA DE TODA LA APP ───────────────
   hablar('lo que sea')  →  el usuario lo oye.

   Hace tres cosas a la vez:
     a) lo dice en voz alta
     b) lo escribe en la región aria-live, para que TalkBack
        y VoiceOver también lo lean
     c) lo guarda por si el usuario pide "repetir"           */

var ultimaFrase = 'Todavía no hay instrucciones.';

function hablar(texto, urgente){
  ultimaFrase = texto;

  // (b) el lector de pantalla del celular lee esto solo
  var aviso = document.getElementById('avisoLector');
  if (aviso) aviso.textContent = texto;

  if (!estado.audioActivo) return;
  if (!('speechSynthesis' in window)) return;

  try {
    // urgente = corta lo que estuviera diciendo. Para peligros.
    if (urgente) speechSynthesis.cancel();

    var frase = new SpeechSynthesisUtterance(texto);
    if (vozES) frase.voice = vozES;
    frase.lang = vozES ? vozES.lang : 'es-CO';
    frase.rate = CONFIG.VELOCIDAD_VOZ;
    speechSynthesis.speak(frase);
  } catch (e) { /* el navegador aún no permite hablar */ }
}

function repetir(){
  hablar(ultimaFrase, true);
}

/* Vibración: el tercer canal, después del oído y la vista.
   Solo funciona en Android; en iPhone no hace nada y no falla. */
function vibrar(patron){
  try { if (navigator.vibrate) navigator.vibrate(patron); } catch (e) {}
}


/* ── 3. LOS COMANDOS DE VOZ ───────────────────────────────
   El usuario no ve los botones, así que tiene que poder
   hablarle a la app.

   OJO: SpeechRecognition solo existe en Chrome y Edge. Por
   eso se pregunta primero si existe. Sin esa comprobación,
   en Firefox se rompería TODA la app, no solo el micrófono. */

var Reconocedor = window.SpeechRecognition || window.webkitSpeechRecognition;
var escucha = null;
var escuchando = false;

if (Reconocedor) {
  escucha = new Reconocedor();
  escucha.lang = 'es-CO';
  escucha.continuous = false;
  escucha.interimResults = false;

  escucha.onresult = function (e) {
    var dicho = (e.results[0][0].transcript || '').toLowerCase().trim();
    interpretar(dicho);
  };

  escucha.onerror = function (e) {
    if (e.error === 'not-allowed')
      hablar('No tengo permiso para el micrófono. Toque el candado en la barra de direcciones y permita el micrófono.', true);
    else if (e.error === 'no-speech')
      hablar('No escuché nada. Intente otra vez.', true);
  };

  escucha.onend = function () {
    escuchando = false;
    var b = document.getElementById('btnMicro');
    if (b) b.setAttribute('aria-pressed', 'false');
  };
}

function alternarMicrofono(){
  if (!escucha) {
    hablar('Los comandos de voz necesitan Chrome o Edge, y una dirección que empiece por https.', true);
    return;
  }
  if (escuchando) { try { escucha.stop(); } catch (e) {} return; }
  try {
    escucha.start();
    escuchando = true;
    var b = document.getElementById('btnMicro');
    if (b) b.setAttribute('aria-pressed', 'true');
    hablar('Escuchando.', true);
  } catch (e) {}
}


/* ── 4. ENTENDER LO QUE DIJO ──────────────────────────────
   No hay inteligencia artificial aquí: se busca una palabra
   clave dentro de la frase y se decide qué hacer. Es simple
   y funciona sorprendentemente bien.                        */

function interpretar(dicho){
  function tiene(){
    for (var i = 0; i < arguments.length; i++) {
      if (dicho.indexOf(arguments[i]) >= 0) return true;
    }
    return false;
  }

  // Reportar
  if (tiene('obstáculo','obstaculo','obra'))       return crearReporte('obstaculo');
  if (tiene('acera','hueco','bache','andén'))      return crearReporte('acera');
  if (tiene('semáforo','semaforo'))                return crearReporte('semaforo');
  if (tiene('rampa','acceso'))                     return crearReporte('rampa');
  if (tiene('accidente','emergencia'))             return crearReporte('accidente');

  // Preguntar
  if (tiene('dónde','donde','ubicación','ubicacion')) return decirUbicacion();
  if (tiene('cuánto','cuanto','falta'))               return decirCuantoFalta();
  if (tiene('novedad','alrededor','cerca'))           return leerNovedades();
  if (tiene('repet','otra vez'))                      return repetir();

  // Moverse por la app
  if (tiene('mapa'))       return mostrar('p-mapa');
  if (tiene('comunidad'))  return mostrar('p-comunidad');
  if (tiene('configura','ajustes')) return mostrar('p-config');

  if (tiene('ayuda','comandos')) {
    return hablar('Puede decir: reportar obstáculo, reportar acera, dónde estoy, ' +
                  'cuánto falta, qué hay cerca, o repetir.', true);
  }

  hablar('No entendí «' + dicho + '». Diga ayuda para conocer los comandos.', true);
}
