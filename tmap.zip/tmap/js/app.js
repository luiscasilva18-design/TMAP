/* ============================================================
   app.js
   ------------------------------------------------------------
   El director de orquesta. Va de ÚLTIMO en el index.html
   porque usa cosas que definieron todos los demás archivos.

   Hace tres cosas:
     1. mostrar() — cambiar de pantalla
     2. Conectar cada botón del wireframe con su función
     3. Arrancar la app
   ============================================================ */


/* ── 1. CAMBIAR DE PANTALLA ───────────────────────────────
   No hay nueve archivos HTML: hay nueve <section> y solo una
   lleva la clase "activa". Esta función se la quita a todas
   y se la pone a la que toca. Así funcionan las apps de
   verdad: una sola página que cambia de contenido.          */

function mostrar(idPantalla){
  var pantallas = document.querySelectorAll('.pantalla');
  for (var i = 0; i < pantallas.length; i++) {
    pantallas[i].classList.remove('activa');
  }

  var destino = document.getElementById(idPantalla);
  if (!destino) return;
  destino.classList.add('activa');
  estado.pantalla = idPantalla;

  // La barra de abajo no se ve en el splash ni en el semáforo
  var conBarra = ['p-mapa','p-comunidad','p-reportar','p-config','p-novedades','p-ruta'];
  document.getElementById('barraAbajo').hidden = conBarra.indexOf(idPantalla) < 0;

  // Marcar la pestaña correspondiente
  var tabs = document.querySelectorAll('.tab');
  for (var j = 0; j < tabs.length; j++) {
    tabs[j].classList.toggle('activa', tabs[j].getAttribute('data-ir') === idPantalla);
  }

  // El semáforo solo cuenta mientras se está viendo, para no
  // gastar batería ni hablar encima de otra pantalla.
  if (idPantalla === 'p-semaforo') iniciarSemaforo();
  else detenerSemaforo();

  // Cada pantalla se anuncia al entrar: sin esto, una persona
  // ciega no sabría que cambió de sección.
  var nombres = {
    'p-mapa':'Mapa y navegación', 'p-semaforo':'Semáforo',
    'p-novedades':'Novedades en la acera', 'p-lectura':'Modo de lectura',
    'p-reportar':'Reportar evento', 'p-comunidad':'Comunidad',
    'p-ruta':'Planificar ruta', 'p-config':'Configuración'
  };
  if (nombres[idPantalla]) hablar(nombres[idPantalla], true);

  if (idPantalla === 'p-comunidad') pintarMuro();
  if (idPantalla === 'p-novedades') pintarNovedades();

  window.scrollTo(0, 0);
}


/* ── 2. CONECTAR LOS BOTONES ──────────────────────────────
   Un addEventListener por cada botón del wireframe.
   Esta es la parte que "enchufa" el diseño con la lógica.   */

function conectarBotones(){

  /* --- Pantalla 1: inicio --- */
  document.getElementById('btnComenzar').addEventListener('click', function () {
    // El primer clic es el que le da permiso al navegador para
    // hablar y para sonar. Por eso la app arranca con un botón.
    arrancarGPS();
    mostrar('p-mapa');
    hablar('Bienvenido a TMAp. Buscando su ubicación.', true);
  });

  /* --- Pantalla 2: mapa --- */
  document.getElementById('btnMenu').addEventListener('click', function () { mostrar('p-config'); });
  document.getElementById('btnAudioMapa').addEventListener('click', repetir);
  document.getElementById('btnLeer').addEventListener('click', decirUbicacion);
  document.getElementById('btnIrSemaforo').addEventListener('click', function () { mostrar('p-semaforo'); });

  document.getElementById('btnCentrar').addEventListener('click', function () {
    if (estado.hayMapa && estado.posicion) {
      mapa.setCenter({ lat: estado.posicion.lat, lng: estado.posicion.lng });
      hablar('Mapa centrado en su posición.', true);
    } else {
      hablar('Todavía no tengo señal de GPS.', true);
    }
  });
  document.getElementById('btnMas').addEventListener('click', function () {
    if (estado.hayMapa) mapa.setZoom(mapa.getZoom() + 1);
  });
  document.getElementById('btnMenos').addEventListener('click', function () {
    if (estado.hayMapa) mapa.setZoom(mapa.getZoom() - 1);
  });
  document.getElementById('btnNorte').addEventListener('click', function () {
    if (estado.hayMapa) mapa.setHeading(0);
    hablar('Mapa orientado al norte.', true);
  });

  /* --- Pantalla 3: semáforo --- */
  document.getElementById('btnAudioSemaforo').addEventListener('click', leerSemaforo);

  /* --- Pantalla 4: novedades --- */
  document.getElementById('btnLeerNovedades').addEventListener('click', leerNovedades);

  /* --- Pantalla 5: modo de lectura --- */
  document.getElementById('btnMicro').addEventListener('click', alternarMicrofono);
  document.getElementById('btnAudioOnOff').addEventListener('click', function () {
    estado.audioActivo = !estado.audioActivo;
    this.lastChild.textContent = estado.audioActivo ? ' Desactivar audio' : ' Activar audio';
    if (estado.audioActivo) hablar('Audio activado.', true);
    else { try { speechSynthesis.cancel(); } catch (e) {} }
  });

  /* --- Pantalla 6: reportar --- */
  document.getElementById('btnSiguienteReporte').addEventListener('click', function () {
    if (!estado.tipoElegido) { hablar('Primero escoja qué quiere reportar.', true); return; }
    crearReporte(estado.tipoElegido);
    this.disabled = true;
  });

  /* --- Pantalla 7: comunidad, las tres pestañas --- */
  var pestanas = document.querySelectorAll('.pestana');
  for (var i = 0; i < pestanas.length; i++) {
    pestanas[i].addEventListener('click', function () {
      for (var j = 0; j < pestanas.length; j++) pestanas[j].classList.remove('activa');
      this.classList.add('activa');
      filtroActual = this.getAttribute('data-filtro');
      pintarMuro();
      hablar('Mostrando: ' + this.textContent, true);
    });
  }

  /* --- Pantalla 8: planificar ruta --- */
  document.getElementById('btnBuscarRuta').addEventListener('click', function () {
    var texto = document.getElementById('campoHasta').value.trim();
    var partes = texto.split(',');

    if (partes.length === 2 && !isNaN(parseFloat(partes[0])) && !isNaN(parseFloat(partes[1]))) {
      fijarDestino(parseFloat(partes[0]), parseFloat(partes[1]));
      mostrar('p-mapa');
    } else {
      hablar('Escriba las coordenadas separadas por coma, o vaya al mapa y toque su destino.', true);
      mostrar('p-mapa');
    }
  });

  /* --- Pantalla 9: configuración --- */
  var ajustes = document.querySelectorAll('.ajustes li');
  for (var k = 0; k < ajustes.length; k++) {
    ajustes[k].addEventListener('click', function () {
      var accion = this.getAttribute('data-accion');
      if (accion === 'lectura') { mostrar('p-lectura'); return; }
      if (accion === 'voz') {
        CONFIG.VELOCIDAD_VOZ = CONFIG.VELOCIDAD_VOZ >= 1.6 ? 0.9 : CONFIG.VELOCIDAD_VOZ + 0.25;
        hablar('Velocidad de voz: ' + CONFIG.VELOCIDAD_VOZ.toFixed(2) + '.', true);
        return;
      }
      hablar(this.querySelector('b').textContent +
             '. Esta sección está fuera del alcance del MVP.', true);
    });
  }

  document.getElementById('btnGuardarClave').addEventListener('click', function () {
    var clave = document.getElementById('campoClave').value.trim();
    if (clave.length < 20) { hablar('Esa clave se ve muy corta. Las de Google empiezan por AIza.', true); return; }
    guardarClave(clave);
    location.reload();
  });

  /* --- Todos los botones de volver --- */
  var volver = document.querySelectorAll('[data-volver]');
  for (var v = 0; v < volver.length; v++) {
    volver[v].addEventListener('click', function () { mostrar(this.getAttribute('data-volver')); });
  }

  /* --- La barra de abajo --- */
  var tabs = document.querySelectorAll('.tab');
  for (var t = 0; t < tabs.length; t++) {
    tabs[t].addEventListener('click', function () { mostrar(this.getAttribute('data-ir')); });
  }

  /* --- Atajos de teclado, para probar desde el computador --- */
  document.addEventListener('keydown', function (e) {
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'BUTTON')) return;
    var k = e.key.toLowerCase();
    if (k === 'd') decirUbicacion();
    if (k === 'r') mostrar('p-reportar');
    if (k === 'v') alternarMicrofono();
    if (k === 'n') mostrar('p-novedades');
    if (e.key === ' ') { e.preventDefault(); repetir(); }
  });
}


/* ── 3. ARRANCAR ──────────────────────────────────────────  */

(function arrancar(){
  recuperarReportes();
  pintarTipos();
  pintarMuro();
  pintarNovedades();
  conectarBotones();

  var clave = leerClaveGuardada();
  var campo = document.getElementById('campoClave');
  if (campo && clave) campo.value = clave;

  cargarGoogleMaps(clave);

  // Arranca en el splash. El GPS no se enciende hasta que el
  // usuario pulsa «Comenzar», porque los navegadores exigen un
  // gesto del usuario antes de permitir audio y ubicación.
  mostrar('p-inicio');
})();
