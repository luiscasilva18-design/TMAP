/* ============================================================
   mapa.js
   ------------------------------------------------------------
   La pantalla 2 del wireframe. Hace cuatro cosas:
     1. Carga el mapa de Google con tu clave
     2. Sigue al usuario con el GPS real (watchPosition)
     3. Calcula la ruta a pie cuando se toca un destino
     4. Va narrando las instrucciones según la distancia real

   Si no hay clave de Google, TODO lo demás sigue funcionando:
   el GPS, la voz, las rutas por rumbo y los reportes. Eso se
   llama degradación elegante y es una decisión de ingeniería,
   no un parche.
   ============================================================ */

var mapa = null;
var marcadorYo = null;
var circuloPrecision = null;
var marcadorDestino = null;
var pintorRuta = null;
var marcadoresReporte = [];
var vigilante = null;          // el identificador de watchPosition
var primerFix = true;


/* ── 1. CARGAR GOOGLE MAPS ────────────────────────────────
   No se puede poner el <script> de Google en el index.html
   porque la clave no está escrita ahí: la trae config.js o
   la que el usuario guardó. Así que se crea el <script> a
   mano y se añade a la página.                              */

function cargarGoogleMaps(clave){
  if (!clave) { sinMapa('Sin clave de Google. El GPS, la voz y los reportes funcionan igual.'); return; }

  var s = document.createElement('script');
  s.src = 'https://maps.googleapis.com/maps/api/js'
        + '?key=' + encodeURIComponent(clave)
        + '&language=es&region=CO'
        + '&callback=iniciarMapa';          // Google llamará a esta función al terminar
  s.async = true;
  s.onerror = function () { sinMapa('No se pudo contactar a Google. Revise su conexión.'); };
  document.head.appendChild(s);
}

/* Google llama a ESTA función si la clave es inválida o si
   falta activar la facturación. El nombre es obligatorio.   */
window.gm_authFailure = function(){
  sinMapa('Google rechazó la clave. Revise que esté bien copiada, que «Maps JavaScript API» esté habilitada y que la facturación esté activa.');
};

function sinMapa(motivo){
  estado.hayMapa = false;
  var aviso = document.getElementById('mapaAviso');
  if (aviso) { aviso.hidden = false; aviso.textContent = motivo; }
}

/* El nombre "iniciarMapa" tiene que coincidir exactamente con
   el &callback= de la URL de arriba. Si lo cambias en un lado
   y no en el otro, el mapa nunca aparece.                    */
window.iniciarMapa = function(){
  estado.hayMapa = true;
  var aviso = document.getElementById('mapaAviso');
  if (aviso) aviso.hidden = true;

  mapa = new google.maps.Map(document.getElementById('mapa'), {
    center: CONFIG.CENTRO_POR_DEFECTO,
    zoom: 17,
    disableDefaultUI: true,
    gestureHandling: 'greedy',
    // Estos colores son los que hacen que el mapa se vea oscuro
    // como en el wireframe, en vez del blanco de Google.
    styles: [
      { elementType:'geometry',            stylers:[{ color:'#141A26' }] },
      { elementType:'labels.text.stroke',  stylers:[{ color:'#05070C' }] },
      { elementType:'labels.text.fill',    stylers:[{ color:'#98A2B5' }] },
      { featureType:'road',     elementType:'geometry', stylers:[{ color:'#232C3D' }] },
      { featureType:'road.arterial', elementType:'geometry', stylers:[{ color:'#2E3A4F' }] },
      { featureType:'water',    elementType:'geometry', stylers:[{ color:'#0A1220' }] },
      { featureType:'poi',      elementType:'labels',   stylers:[{ visibility:'off' }] },
      { featureType:'transit',  elementType:'labels',   stylers:[{ visibility:'off' }] }
    ]
  });

  // El punto azul del usuario
  marcadorYo = new google.maps.Marker({
    map: mapa, title: 'Usted',
    icon: { path: google.maps.SymbolPath.CIRCLE, scale: 8,
            fillColor:'#1E6FFF', fillOpacity:1, strokeColor:'#FFFFFF', strokeWeight:3 }
  });

  // El círculo que muestra cuánto error tiene el GPS
  circuloPrecision = new google.maps.Circle({
    map: mapa, strokeColor:'#1E6FFF', strokeOpacity:.35, strokeWeight:1,
    fillColor:'#1E6FFF', fillOpacity:.10
  });

  // La línea de la ruta
  pintorRuta = new google.maps.DirectionsRenderer({
    map: mapa, suppressMarkers:true, preserveViewport:true,
    polylineOptions:{ strokeColor:'#1E6FFF', strokeWeight:7, strokeOpacity:.95 }
  });

  // Tocar el mapa fija el destino
  mapa.addListener('click', function (e) {
    fijarDestino(e.latLng.lat(), e.latLng.lng());
  });

  if (estado.posicion) pintarPosicion();
  dibujarReportesEnMapa();
};


/* ── 2. EL GPS REAL ───────────────────────────────────────
   getCurrentPosition pregunta UNA vez.
   watchPosition avisa CADA VEZ que el usuario se mueve.
   Para una app de navegación siempre es watchPosition.      */

function arrancarGPS(){
  if (!navigator.geolocation) {
    hablar('Este navegador no permite acceder a la ubicación.', true);
    return;
  }
  vigilante = navigator.geolocation.watchPosition(alMoverse, falloGPS, {
    enableHighAccuracy: true,   // usa el chip GPS, no solo el wifi
    maximumAge: 1000,
    timeout: 20000
  });
}

function falloGPS(error){
  var motivos = {
    1: 'No dio permiso para usar la ubicación. Toque el candado de la barra de direcciones y permita la ubicación.',
    2: 'No hay señal de GPS. Salga al aire libre o acérquese a una ventana.',
    3: 'La búsqueda del GPS tardó demasiado.'
  };
  hablar(motivos[error.code] || 'No se pudo obtener la ubicación.', true);
}

/* Esta función se ejecuta SOLA cada vez que el usuario se
   mueve. Es el latido de toda la app.                       */
function alMoverse(pos){
  estado.posicion = {
    lat:       pos.coords.latitude,
    lng:       pos.coords.longitude,
    precision: pos.coords.accuracy,
    rumbo:     (pos.coords.heading === null || isNaN(pos.coords.heading)) ? null : pos.coords.heading,
    velocidad: pos.coords.speed || 0
  };

  if (primerFix) {
    primerFix = false;
    reanclarEjemplos();          // pone los reportes de ejemplo cerca del usuario
    pintarNovedades();
    pintarMuro();
    dibujarReportesEnMapa();
    hablar('Ubicación encontrada, con una precisión de ' +
           Math.round(estado.posicion.precision) + ' metros. ' +
           (estado.hayMapa ? 'Toque el mapa para fijar su destino.' : ''), true);
  }

  pintarPosicion();
  if (estado.destino) seguirRuta();
  revisarPeligros();             // vive en reportes.js
}

function pintarPosicion(){
  if (!estado.hayMapa || !estado.posicion || !marcadorYo) return;
  var p = new google.maps.LatLng(estado.posicion.lat, estado.posicion.lng);
  marcadorYo.setPosition(p);
  circuloPrecision.setCenter(p);
  circuloPrecision.setRadius(Math.max(5, estado.posicion.precision));
  if (!estado.destino) mapa.setCenter(p);
}


/* ── 3. FIJAR EL DESTINO Y CALCULAR LA RUTA ───────────────  */

function fijarDestino(lat, lng){
  estado.destino = { lat: lat, lng: lng };
  estado.pasos = [];
  estado.pasoActual = 0;
  estado.avisados = {};

  var campo = document.getElementById('campoHasta');
  if (campo) campo.value = lat.toFixed(5) + ', ' + lng.toFixed(5);

  if (estado.hayMapa) {
    if (marcadorDestino) marcadorDestino.setMap(null);
    marcadorDestino = new google.maps.Marker({
      map: mapa, position: estado.destino, title: 'Destino',
      icon: { path: google.maps.SymbolPath.BACKWARD_CLOSED_ARROW, scale: 6,
              fillColor:'#22C55E', fillOpacity:1, strokeColor:'#05070C', strokeWeight:2 }
    });
  }

  if (!estado.posicion) { hablar('Destino marcado. Esperando la señal del GPS.', true); return; }
  calcularRuta();
}

function calcularRuta(){
  var recta = Math.round(distancia(estado.posicion.lat, estado.posicion.lng,
                                   estado.destino.lat, estado.destino.lng));
  hablar('Destino a ' + recta + ' metros en línea recta. Calculando la ruta a pie.', true);

  // Sin Google no hay Directions: guiamos por rumbo y distancia.
  if (!estado.hayMapa || !window.google || !google.maps.DirectionsService) { guiaDirecta(); return; }

  new google.maps.DirectionsService().route({
    origin:      { lat: estado.posicion.lat, lng: estado.posicion.lng },
    destination: estado.destino,
    travelMode:  google.maps.TravelMode.WALKING     // A PIE, no en carro
  }, function (resultado, estadoRespuesta) {

    if (estadoRespuesta !== 'OK' || !resultado.routes.length) {
      hablar('No pude calcular la ruta a pie. Le guío por dirección y distancia.', true);
      guiaDirecta();
      return;
    }

    pintorRuta.setDirections(resultado);
    var tramo = resultado.routes[0].legs[0];

    // Google devuelve los pasos con etiquetas HTML dentro.
    // Aquí los convertimos a algo que se pueda decir en voz.
    estado.pasos = tramo.steps.map(function (s) {
      return {
        texto:    limpiarHTML(s.instructions),
        metros:   s.distance ? s.distance.value : 0,
        finLat:   s.end_location.lat(),
        finLng:   s.end_location.lng(),
        maniobra: s.maneuver || ''
      };
    });
    estado.pasoActual = 0;

    var resumen = tramo.distance.text + ' · ' + tramo.duration.text + ' caminando';
    ponerTexto('rutaResumen', resumen);
    ponerTexto('rutaDetalle', estado.pasos.length + ' pasos en la ruta');

    hablar('Ruta lista: ' + resumen + '. ' + estado.pasos[0].texto, true);
    mostrarPasoActual();
    if (resultado.routes[0].bounds) mapa.fitBounds(resultado.routes[0].bounds, 50);
  });
}

function limpiarHTML(html){
  var d = document.createElement('div');
  d.innerHTML = html;
  return (d.textContent || '').replace(/\s+/g, ' ').trim();
}


/* ── 4. IR NARRANDO LA RUTA ───────────────────────────────
   Se ejecuta cada vez que el GPS reporta movimiento.        */

function seguirRuta(){
  if (!estado.pasos.length) { guiaDirecta(); return; }
  if (estado.pasoActual >= estado.pasos.length) return;

  var paso = estado.pasos[estado.pasoActual];
  var m = Math.round(distancia(estado.posicion.lat, estado.posicion.lng, paso.finLat, paso.finLng));

  ponerTexto('abajoMetros', m + ' m');
  ponerTexto('insPrincipal', paso.texto);

  // Aviso anticipado a 30 metros, una sola vez por paso.
  var marca = 'p' + estado.pasoActual + '-30';
  if (m <= 30 && m > 12 && !estado.avisados[marca]) {
    estado.avisados[marca] = true;
    var prox = estado.pasos[estado.pasoActual + 1];
    if (prox) hablar('En 30 metros, ' + prox.texto.toLowerCase());
  }

  // Llegó al final del paso: pasa al siguiente.
  if (m <= 12) {
    estado.pasoActual++;
    if (estado.pasoActual >= estado.pasos.length) {
      hablar('Llegaste a tu destino.', true);
      vibrar([200,100,200,100,200]);
      ponerTexto('insPrincipal', 'Llegaste a tu destino');
      ponerTexto('insSecundaria', 'Recorrido terminado.');
      ponerTexto('abajoMetros', '0 m');
      ponerTexto('abajoTexto', 'Destino');
      return;
    }
    mostrarPasoActual();
    hablar(estado.pasos[estado.pasoActual].texto, true);
    vibrar([120,60,120]);
  }
}

function mostrarPasoActual(){
  var paso = estado.pasos[estado.pasoActual];
  if (!paso) return;
  ponerTexto('insPrincipal', paso.texto);
  ponerTexto('insSecundaria', 'Paso ' + (estado.pasoActual + 1) + ' de ' + estado.pasos.length);
  ponerTexto('abajoTexto', paso.maniobra.indexOf('cross') >= 0 ? 'Cruce peatonal' : 'Siga la acera');
}

/* Sin ruta de Google: rumbo y distancia. Muchas apps de
   accesibilidad navegan exactamente así.                    */
function guiaDirecta(){
  if (!estado.posicion || !estado.destino) return;

  var m = Math.round(distancia(estado.posicion.lat, estado.posicion.lng,
                               estado.destino.lat, estado.destino.lng));
  var r = rumbo(estado.posicion.lat, estado.posicion.lng,
                estado.destino.lat, estado.destino.lng);

  ponerTexto('insPrincipal', m <= 15 ? 'Llegaste a tu destino' : 'El destino queda ' + cardinal(r));
  ponerTexto('insSecundaria', estado.posicion.rumbo !== null
      ? giro(r, estado.posicion.rumbo)
      : 'Camine unos metros para que el celular sepa hacia dónde mira.');
  ponerTexto('abajoMetros', m + ' m');
  ponerTexto('abajoTexto', 'En línea recta');

  // Avisa cada 25 metros, sin repetirse.
  var marca = 'd' + Math.floor(m / 25);
  if (!estado.avisados[marca] && m > 15) {
    estado.avisados[marca] = true;
    var frase = 'A ' + m + ' metros, ' + cardinal(r) + '.';
    if (estado.posicion.rumbo !== null) frase += ' ' + giro(r, estado.posicion.rumbo) + '.';
    hablar(frase);
  }
  if (m <= 15 && !estado.avisados.llegada) {
    estado.avisados.llegada = true;
    hablar('Llegaste a tu destino.', true);
    vibrar([200,100,200,100,200]);
  }
}


/* ── 5. RESPUESTAS HABLADAS ───────────────────────────────  */

function decirUbicacion(){
  if (!estado.posicion) { hablar('Todavía no tengo señal de GPS.', true); return; }

  var t = 'Está en latitud ' + estado.posicion.lat.toFixed(4) +
          ', longitud ' + estado.posicion.lng.toFixed(4) +
          ', con una precisión de ' + Math.round(estado.posicion.precision) + ' metros.';

  if (estado.destino) {
    var m = Math.round(distancia(estado.posicion.lat, estado.posicion.lng,
                                 estado.destino.lat, estado.destino.lng));
    t += ' Su destino está a ' + m + ' metros ' +
         cardinal(rumbo(estado.posicion.lat, estado.posicion.lng,
                        estado.destino.lat, estado.destino.lng)) + '.';
  }
  hablar(t, true);
}

function decirCuantoFalta(){
  if (!estado.destino)  { hablar('Todavía no ha fijado un destino. Toque el mapa.', true); return; }
  if (!estado.posicion) { hablar('Todavía no tengo señal de GPS.', true); return; }
  var m = Math.round(distancia(estado.posicion.lat, estado.posicion.lng,
                               estado.destino.lat, estado.destino.lng));
  hablar('Le faltan unos ' + m + ' metros, ' +
         cardinal(rumbo(estado.posicion.lat, estado.posicion.lng,
                        estado.destino.lat, estado.destino.lng)) + '.', true);
}

/* Atajo que se repite en todos los archivos: escribir un
   texto dentro de un elemento, sin que falle si no existe.  */
function ponerTexto(id, texto){
  var el = document.getElementById(id);
  if (el) el.textContent = texto;
}
