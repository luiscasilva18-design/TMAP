/* ============================================================
   reportes.js
   ------------------------------------------------------------
   Las pantallas 4, 6 y 7 del wireframe. Las tres leen la MISMA
   lista de reportes, solo que la muestran distinto:

     Pantalla 6 «Reportar»   → crea un reporte
     Pantalla 4 «Novedades»  → los ordena por distancia
     Pantalla 7 «Comunidad»  → los ordena por hora, con votos

   Y además, la función más importante de todas:
     revisarPeligros() → avisa por voz cuando te acercas a uno.
   ============================================================ */


/* ── 1. CREAR UN REPORTE ──────────────────────────────────
   Un reporte no es más que una ficha con seis casillas que
   se agrega al final de la lista.                           */

function crearReporte(tipoId){
  if (!estado.posicion) {
    hablar('Todavía no tengo su ubicación. Espere a que el GPS tenga señal.', true);
    return;
  }

  var tipo = buscarTipo(tipoId);

  reportes.push({
    id:          'r' + Date.now(),
    tipo:        tipoId,
    lat:         estado.posicion.lat,     // las coordenadas REALES donde está parado
    lng:         estado.posicion.lng,
    hora:        Date.now(),
    votos:       0,
    comentarios: 0,
    mio:         true,
    avisado:     true                     // no hay que avisarle a quien acaba de reportarlo
  });

  hablar('Reporte enviado: ' + tipo.nombre + '. Quedó registrado en su ubicación. ' +
         'Los peatones que pasen cerca serán avisados.', true);
  vibrar([60, 40, 60]);

  guardarReportes();
  pintarMuro();
  pintarNovedades();
  dibujarReportesEnMapa();

  estado.tipoElegido = null;
  mostrar('p-comunidad');
}


/* ── 2. LA ALERTA DE PROXIMIDAD ───────────────────────────
   Esto es lo que convierte una lista de reportes en un
   sistema de seguridad. Se ejecuta cada vez que el GPS dice
   que el usuario se movió.

   La bandera 'avisado' es el detalle que lo hace usable: sin
   ella, la app repetiría la alerta cada segundo durante 30
   metros y sería insoportable.                              */

function revisarPeligros(){
  if (!estado.posicion) return;

  reportes.forEach(function (r) {
    var d = distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng);

    if (d <= CONFIG.RADIO_ALERTA && !r.avisado) {
      r.avisado = true;
      var tipo = buscarTipo(r.tipo);
      hablar('Atención. ' + tipo.nombre + ' a ' + Math.round(d) +
             ' metros. Reportado por otro peatón.', true);
      vibrar([260, 90, 260]);
    }

    // Si se alejó bastante, el aviso se rearma para la próxima vez.
    if (d > CONFIG.RADIO_ALERTA * 2) r.avisado = false;
  });

  pintarNovedades();
}


/* ── 3. PANTALLA 6 — LAS SEIS TARJETAS ────────────────────
   No están escritas en el HTML: se dibujan aquí recorriendo
   la lista TIPOS de datos.js. Por eso agregar un tipo nuevo
   no obliga a tocar el HTML.                                */

function pintarTipos(){
  var caja = document.getElementById('rejillaTipos');
  if (!caja) return;
  caja.textContent = '';

  TIPOS.forEach(function (t) {
    var b = document.createElement('button');
    b.className = 'tipo-tarjeta';
    b.type = 'button';
    b.setAttribute('aria-pressed', 'false');
    b.innerHTML =
      '<span class="circulo ' + t.color + '"><svg viewBox="0 0 24 24" class="ico">' +
      ICONOS[t.icono] + '</svg></span>' + t.nombre;

    b.addEventListener('click', function () {
      // Marcar esta y desmarcar las demás
      var todas = caja.querySelectorAll('.tipo-tarjeta');
      for (var i = 0; i < todas.length; i++) todas[i].setAttribute('aria-pressed', 'false');
      b.setAttribute('aria-pressed', 'true');

      estado.tipoElegido = t.id;
      document.getElementById('btnSiguienteReporte').disabled = false;
      hablar(t.nombre + ' seleccionado. Pulse Siguiente para enviar.', true);
    });

    caja.appendChild(b);
  });
}


/* ── 4. PANTALLA 4 — NOVEDADES, ORDENADAS POR DISTANCIA ───  */

function pintarNovedades(){
  var ul = document.getElementById('listaNovedades');
  if (!ul) return;
  ul.textContent = '';

  var lista = reportes.slice();

  // Si hay GPS, ordenar por cercanía y quedarse con lo que está a menos de 300 m
  if (estado.posicion) {
    lista.forEach(function (r) {
      r._d = distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng);
    });
    lista = lista.filter(function (r) { return r._d < 300; });
    lista.sort(function (a, b) { return a._d - b._d; });
  }

  lista.forEach(function (r) {
    var t = buscarTipo(r.tipo);
    var li = document.createElement('li');
    li.innerHTML =
      '<span class="circulo ' + t.color + '"><svg viewBox="0 0 24 24" class="ico">' + ICONOS[t.icono] + '</svg></span>' +
      '<span class="txt"><b>' + t.nombre + '</b><p>' + t.ejemplo + '</p></span>' +
      '<span class="dist">' + (r._d !== undefined ? Math.round(r._d) + ' m' : '—') + '</span>';
    ul.appendChild(li);
  });

  document.getElementById('novedadesVacio').hidden = lista.length > 0;
}

/* El botón «Reproducir todas las novedades» */
function leerNovedades(){
  if (!estado.posicion) { hablar('Todavía no tengo señal de GPS.', true); return; }

  var cerca = reportes.filter(function (r) {
    return distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng) < 300;
  });

  if (!cerca.length) { hablar('No hay novedades a menos de 300 metros.', true); return; }

  cerca.sort(function (a, b) {
    return distancia(estado.posicion.lat, estado.posicion.lng, a.lat, a.lng) -
           distancia(estado.posicion.lat, estado.posicion.lng, b.lat, b.lng);
  });

  var frase = 'Hay ' + cerca.length + (cerca.length === 1 ? ' novedad cerca. ' : ' novedades cerca. ');
  cerca.forEach(function (r) {
    var d = Math.round(distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng));
    frase += buscarTipo(r.tipo).nombre + ', a ' + d + ' metros. ';
  });
  hablar(frase, true);
}


/* ── 5. PANTALLA 7 — EL MURO DE LA COMUNIDAD ──────────────  */

var filtroActual = 'todos';

function pintarMuro(){
  var ul = document.getElementById('muro');
  if (!ul) return;
  ul.textContent = '';

  var lista = reportes.slice();

  if (filtroActual === 'mios') {
    lista = lista.filter(function (r) { return r.mio; });
  } else if (filtroActual === 'cerca' && estado.posicion) {
    lista = lista.filter(function (r) {
      return distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng) < 300;
    });
  }

  lista.sort(function (a, b) { return b.hora - a.hora; });   // lo más reciente primero

  lista.forEach(function (r) {
    var t = buscarTipo(r.tipo);
    var d = estado.posicion
          ? Math.round(distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng)) + ' m'
          : '—';

    var li = document.createElement('li');
    li.innerHTML =
      '<span class="circulo ' + t.color + '"><svg viewBox="0 0 24 24" class="ico">' + ICONOS[t.icono] + '</svg></span>' +
      '<span class="txt">' +
        '<b>' + t.nombre + '</b>' +
        '<span class="meta">' + haceCuanto(r.hora) + ' · ' + d + '</span>' +
        '<p class="desc">' + t.ejemplo + '</p>' +
        '<span class="acciones">' +
          '<button type="button" data-votar="' + r.id + '">' +
            '<svg viewBox="0 0 24 24" class="ico">' + ICONOS.pulgar + '</svg>' + r.votos +
          '</button>' +
          '<button type="button" data-leer="' + r.id + '">' +
            '<svg viewBox="0 0 24 24" class="ico">' + ICONOS.comentario + '</svg>' + r.comentarios +
          '</button>' +
        '</span>' +
      '</span>';
    ul.appendChild(li);
  });

  document.getElementById('muroVacio').hidden = lista.length > 0;

  // Conectar los botones de votar y de leer en voz alta
  ul.querySelectorAll('[data-votar]').forEach(function (b) {
    b.addEventListener('click', function () { votar(b.getAttribute('data-votar')); });
  });
  ul.querySelectorAll('[data-leer]').forEach(function (b) {
    b.addEventListener('click', function () { leerReporte(b.getAttribute('data-leer')); });
  });
}

function votar(id){
  reportes.forEach(function (r) {
    if (r.id !== id) return;
    r.votos++;
    hablar('Confirmó que ' + buscarTipo(r.tipo).nombre.toLowerCase() +
           ' sigue ahí. Ahora son ' + r.votos + ' confirmaciones.', true);
  });
  guardarReportes();
  pintarMuro();
}

function leerReporte(id){
  reportes.forEach(function (r) {
    if (r.id !== id) return;
    var t = buscarTipo(r.tipo);
    var d = estado.posicion
          ? ', a ' + Math.round(distancia(estado.posicion.lat, estado.posicion.lng, r.lat, r.lng)) + ' metros'
          : '';
    hablar(t.nombre + d + '. ' + t.ejemplo + ' Reportado ' + haceCuanto(r.hora) +
           ', con ' + r.votos + ' confirmaciones.', true);
  });
}


/* ── 6. LOS PUNTOS EN EL MAPA ─────────────────────────────  */

function dibujarReportesEnMapa(){
  if (!estado.hayMapa) return;

  marcadoresReporte.forEach(function (m) { m.setMap(null); });
  marcadoresReporte = [];

  var colores = { rojo:'#EF4444', amarillo:'#FACC15', verde:'#22C55E',
                  cyan:'#38BDF8', morado:'#A855F7', gris:'#3A465C' };

  reportes.forEach(function (r) {
    var t = buscarTipo(r.tipo);
    marcadoresReporte.push(new google.maps.Marker({
      map: mapa,
      position: { lat: r.lat, lng: r.lng },
      title: t.nombre,
      icon: { path: google.maps.SymbolPath.CIRCLE, scale: 7,
              fillColor: colores[t.color] || '#3A465C', fillOpacity: 1,
              strokeColor: '#05070C', strokeWeight: 2 }
    }));
  });
}
