/* ============================================================
   config.js
   ------------------------------------------------------------
   ESTE ES EL ÚNICO ARCHIVO QUE TIENES QUE EDITAR PARA ARRANCAR.
   Todo lo demás ya está escrito y conectado.
   ============================================================ */

var CONFIG = {

  /* 1 ── LA CLAVE DE GOOGLE ────────────────────────────────
     Pega aquí, entre las comillas, la clave que sacaste en
     Google Cloud Console (empieza por AIza...).

     Si la dejas vacía, TMAp funciona igual: GPS, voz, rutas
     por rumbo y reportes. Lo único que falta es el mapa de
     fondo. Para la sustentación sirve perfectamente.        */

  CLAVE_GOOGLE: '',


  /* 2 ── A CUÁNTOS METROS AVISAR DE UN PELIGRO ─────────────
     Cuando el usuario se acerca a menos de esta distancia de
     un reporte, la app lo avisa por voz y vibra.
     30 metros son unos 30 pasos: da tiempo de reaccionar.   */

  RADIO_ALERTA: 30,


  /* 3 ── VELOCIDAD DE LA VOZ ───────────────────────────────
     1 es la velocidad normal. Las personas ciegas con
     experiencia suelen subirla a 1.5 o más.                 */

  VELOCIDAD_VOZ: 1.05,


  /* 4 ── DÓNDE CENTRAR EL MAPA MIENTRAS LLEGA EL GPS ───────
     Por defecto: Carrera 13 con Calle 63, Bogotá.
     Para cambiarlo: abre Google Maps, clic derecho sobre el
     punto que quieras y copia las dos cifras que aparecen.  */

  CENTRO_POR_DEFECTO: { lat: 4.6512, lng: -74.0625 },


  /* 5 ── TIEMPOS DEL SEMÁFORO DE DEMOSTRACIÓN (segundos) ───
     La duración real de un semáforo no es pública, así que
     el MVP la simula. Estos son valores típicos de un cruce
     peatonal en Bogotá.                                     */

  SEMAFORO: { rojo: 32, amarillo: 3, verde: 12 }

};
