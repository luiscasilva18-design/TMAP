/* ============================================================
   datos.js
   ------------------------------------------------------------
   Lo que TODAS las pantallas necesitan:
     1. Los tipos de reporte (las seis tarjetas del wireframe)
     2. Los dibujos de los iconos
     3. El "estado": lo que la app sabe en este momento
     4. Los cálculos con coordenadas (distancia y rumbo)
     5. Guardar y recuperar del navegador

   No toca la pantalla. Solo guarda datos y hace cuentas.
   ============================================================ */


/* ── 1. LOS TIPOS DE REPORTE ──────────────────────────────
   Esta lista manda sobre tres pantallas a la vez: las
   tarjetas de "Reportar", el muro de "Comunidad" y la lista
   de "Novedades". Si agregas un tipo aquí, aparece en las
   tres sin tocar nada más.                                  */

var TIPOS = [
  { id:'obstaculo', nombre:'Obstáculo en la acera',      color:'rojo',     icono:'alerta',   gravedad:'critico',
    ejemplo:'Hay una obra, toca rodear por la calle.' },
  { id:'acera',     nombre:'Acera en mal estado',        color:'amarillo', icono:'triangulo',gravedad:'alto',
    ejemplo:'Hay un hueco grande en la acera.' },
  { id:'semaforo',  nombre:'Semáforo fuera de servicio', color:'verde',    icono:'semaforo', gravedad:'alto',
    ejemplo:'El semáforo no cambia, parece dañado.' },
  { id:'rampa',     nombre:'Rampa o acceso inaccesible', color:'cyan',     icono:'silla',    gravedad:'medio',
    ejemplo:'Entrada con rampa en la biblioteca.' },
  { id:'accidente', nombre:'Accidente o emergencia',     color:'rojo',     icono:'alerta',   gravedad:'critico',
    ejemplo:'Accidente en la intersección.' },
  { id:'otro',      nombre:'Otro',                       color:'gris',     icono:'puntos',   gravedad:'medio',
    ejemplo:'Novedad reportada por un peatón.' }
];

function buscarTipo(id){
  for (var i = 0; i < TIPOS.length; i++) {
    if (TIPOS[i].id === id) return TIPOS[i];
  }
  return TIPOS[TIPOS.length - 1];   // si no existe, devuelve "Otro"
}


/* ── 2. LOS DIBUJOS DE LOS ICONOS ─────────────────────────
   Cada uno es el interior de un <svg>. Se usan así:
     '<svg viewBox="0 0 24 24" class="ico">' + ICONOS.alerta + '</svg>'   */

var ICONOS = {
  alerta:    '<circle cx="12" cy="12" r="9"/><path d="M12 7v6"/><path d="M12 16.5h.01"/>',
  triangulo: '<path d="M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  semaforo:  '<rect x="8" y="2" width="8" height="20" rx="3"/><circle cx="12" cy="7" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="17" r="1.6"/>',
  silla:     '<circle cx="14" cy="4" r="2"/><path d="M12 8v6h5l3 6"/><path d="M12 14a5 5 0 103.5 8.5"/>',
  puntos:    '<circle cx="6" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="18" cy="12" r="1.6" fill="currentColor" stroke="none"/>',
  info:      '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/>',
  pulgar:    '<path d="M7 11v9H4v-9z"/><path d="M7 11l4-7a2 2 0 013 2l-1 5h5a2 2 0 012 2.4l-1.4 6A2 2 0 0116.6 21H7"/>',
  comentario:'<path d="M21 12a8 8 0 01-11.6 7.1L3 21l1.9-6.4A8 8 0 1121 12z"/>'
};


/* ── 3. EL ESTADO ─────────────────────────────────────────
   Una sola caja con todo lo que la app sabe ahora mismo.
   Tener esto en un solo sitio evita el caos de variables
   sueltas repartidas por todos los archivos.                */

var estado = {
  posicion:    null,     // {lat, lng, precision, rumbo, velocidad} — lo llena el GPS
  destino:     null,     // {lat, lng} — lo llena el toque en el mapa
  pasos:       [],       // los pasos de la ruta que devuelve Google
  pasoActual:  0,
  audioActivo: true,
  pantalla:    'p-inicio',
  tipoElegido: null,     // qué tarjeta escogió en "Reportar"
  hayMapa:     false,
  avisados:    {}        // para no repetir la misma alerta cada segundo
};

var reportes = [];


/* ── 4. CÁLCULOS CON COORDENADAS ──────────────────────────
   Dos fórmulas de navegación de toda la vida. No dependen
   de Google: funcionan aunque el mapa no cargue.            */

/* Distancia en METROS entre dos puntos de la Tierra.
   Se llama fórmula de Haversine. La Tierra es una esfera,
   así que no sirve el teorema de Pitágoras.                 */
function distancia(lat1, lon1, lat2, lon2){
  var R = 6371000;                 // radio de la Tierra, en metros
  var g = Math.PI / 180;           // para pasar de grados a radianes
  var dLat = (lat2 - lat1) * g;
  var dLon = (lon2 - lon1) * g;
  var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(lat1*g) * Math.cos(lat2*g) * Math.sin(dLon/2) * Math.sin(dLon/2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/* Rumbo en GRADOS desde un punto hacia otro.
   0 = norte, 90 = oriente, 180 = sur, 270 = occidente.      */
function rumbo(lat1, lon1, lat2, lon2){
  var g = Math.PI / 180;
  var y = Math.sin((lon2 - lon1) * g) * Math.cos(lat2 * g);
  var x = Math.cos(lat1*g) * Math.sin(lat2*g) -
          Math.sin(lat1*g) * Math.cos(lat2*g) * Math.cos((lon2 - lon1) * g);
  return (Math.atan2(y, x) / g + 360) % 360;
}

/* Convierte esos grados en algo que se pueda decir en voz alta. */
function cardinal(grados){
  var nombres = ['al norte','al nororiente','al oriente','al suroriente',
                 'al sur','al suroccidente','al occidente','al noroccidente'];
  return nombres[Math.round(grados / 45) % 8];
}

/* Compara hacia dónde mira el usuario con hacia dónde debe ir. */
function giro(rumboDestino, rumboUsuario){
  var d = rumboDestino - rumboUsuario;
  while (d > 180)  d -= 360;
  while (d < -180) d += 360;
  var a = Math.abs(d);
  if (a < 25)  return 'siga derecho';
  if (a > 155) return 'dé media vuelta';
  var lado = d > 0 ? 'derecha' : 'izquierda';
  if (a < 70)  return 'gire levemente a la ' + lado;
  if (a < 120) return 'gire a la ' + lado;
  return 'gire bastante a la ' + lado;
}

/* Cuánto hace que pasó algo, en palabras. */
function haceCuanto(milisegundos){
  var min = Math.round((Date.now() - milisegundos) / 60000);
  if (min < 1)   return 'ahora mismo';
  if (min < 60)  return 'hace ' + min + ' min';
  var h = Math.round(min / 60);
  return 'hace ' + h + (h === 1 ? ' hora' : ' horas');
}


/* ── 5. GUARDAR Y RECUPERAR ───────────────────────────────
   localStorage es un cajoncito que el navegador le presta a
   tu página. Todo va dentro de try/catch porque en ventana
   de incógnito puede estar bloqueado y no queremos que la
   app se caiga por eso.                                     */

var LLAVE_REPORTES = 'tmap.reportes';
var LLAVE_CLAVE    = 'tmap.clave.google';

function guardarReportes(){
  try {
    localStorage.setItem(LLAVE_REPORTES, JSON.stringify(reportes));
  } catch (e) { /* sin almacenamiento: seguimos solo en memoria */ }
}

function recuperarReportes(){
  try {
    var crudo = localStorage.getItem(LLAVE_REPORTES);
    if (crudo) reportes = JSON.parse(crudo);
  } catch (e) { reportes = []; }

  if (!reportes.length) sembrarEjemplos();
  reportes.forEach(function (r) { r.avisado = false; });
}

function leerClaveGuardada(){
  try { return localStorage.getItem(LLAVE_CLAVE) || CONFIG.CLAVE_GOOGLE; }
  catch (e) { return CONFIG.CLAVE_GOOGLE; }
}

function guardarClave(clave){
  try { localStorage.setItem(LLAVE_CLAVE, clave); } catch (e) {}
}

/* Reportes de ejemplo para que Comunidad y Novedades no
   arranquen vacías. Se colocan alrededor del centro por
   defecto y se mueven cerca del usuario en cuanto llega la
   primera señal del GPS (ver reanclarEjemplos).             */
function sembrarEjemplos(){
  var c = CONFIG.CENTRO_POR_DEFECTO;
  reportes = [
    { id:'e1', tipo:'obstaculo', lat:c.lat + 0.00018, lng:c.lng + 0.00010,
      hora:Date.now() - 5*60000,  votos:12, comentarios:3, mio:false, ejemplo:true },
    { id:'e2', tipo:'acera',     lat:c.lat + 0.00042, lng:c.lng - 0.00022,
      hora:Date.now() - 12*60000, votos:8,  comentarios:1, mio:false, ejemplo:true },
    { id:'e3', tipo:'rampa',     lat:c.lat + 0.00090, lng:c.lng + 0.00040,
      hora:Date.now() - 20*60000, votos:15, comentarios:0, mio:false, ejemplo:true },
    { id:'e4', tipo:'semaforo',  lat:c.lat + 0.00160, lng:c.lng - 0.00035,
      hora:Date.now() - 25*60000, votos:7,  comentarios:2, mio:false, ejemplo:true }
  ];
}

/* Mueve los ejemplos cerca de donde esté el usuario, para que
   la demostración tenga contenido en cualquier ciudad.       */
function reanclarEjemplos(){
  if (!estado.posicion) return;
  var c = CONFIG.CENTRO_POR_DEFECTO;
  reportes.forEach(function (r) {
    if (!r.ejemplo) return;
    r.lat = estado.posicion.lat + (r.lat - c.lat);
    r.lng = estado.posicion.lng + (r.lng - c.lng);
  });
}
