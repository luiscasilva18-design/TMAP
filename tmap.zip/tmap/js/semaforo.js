/* ============================================================
   semaforo.js
   ------------------------------------------------------------
   La pantalla 3 del wireframe.

   HONESTIDAD TÉCNICA, y conviene decirlo en la sustentación:
   los tiempos reales de los semáforos de Bogotá NO son datos
   públicos. Ninguna app los sabe de verdad; las que muestran
   un contador lo estiman. Aquí se simula un ciclo típico con
   los valores de CONFIG.SEMAFORO.

   Lo que SÍ es real y es lo valioso: el ciclo sonoro. Un
   pitido grave y lento cuando no se puede cruzar, y uno agudo
   y rápido cuando sí. Es exactamente como funcionan los
   semáforos sonoros de verdad.
   ============================================================ */

var relojSemaforo = null;
var luzActual = 'rojo';
var quedan = 0;


/* ── 1. LOS PITIDOS, SIN ARCHIVOS DE SONIDO ───────────────
   El navegador puede generar tonos. Funciona como un equipo
   de sonido con cables: un oscilador (la fuente del tono) se
   conecta a un control de volumen, y ese a los parlantes.   */

var audio = null;

function pitido(frecuencia, duracion){
  try {
    if (!audio) audio = new (window.AudioContext || window.webkitAudioContext)();
    if (audio.state === 'suspended') audio.resume();

    var osc = audio.createOscillator();
    var vol = audio.createGain();
    osc.type = 'square';
    osc.frequency.value = frecuencia;      // en hercios: más alto = más agudo
    vol.gain.value = 0.06;
    osc.connect(vol);
    vol.connect(audio.destination);        // destination = los parlantes
    osc.start();
    osc.stop(audio.currentTime + duracion);
  } catch (e) { /* el navegador aún no permite audio */ }
}


/* ── 2. EL CICLO ──────────────────────────────────────────  */

function iniciarSemaforo(){
  detenerSemaforo();

  luzActual = 'rojo';
  quedan = CONFIG.SEMAFORO.rojo;

  ponerTexto('tRojo',     CONFIG.SEMAFORO.rojo + ' s');
  ponerTexto('tAmarillo', CONFIG.SEMAFORO.amarillo + ' s');
  ponerTexto('tVerde',    CONFIG.SEMAFORO.verde + ' s');

  pintarSemaforo();
  hablar('Semáforo en rojo. No cruce. Faltan ' + quedan + ' segundos.', true);

  relojSemaforo = setInterval(function () {
    quedan--;

    if (luzActual === 'rojo') {
      if (quedan <= 5 && quedan > 0) pitido(440, 0.09);      // grave y lento: espere
      if (quedan <= 0) {
        luzActual = 'verde';
        quedan = CONFIG.SEMAFORO.verde;
        hablar('Verde. Puede cruzar. Tiene ' + quedan + ' segundos. Mantenga la línea recta.', true);
        vibrar([120, 60, 120, 60, 120]);
      }
    } else if (luzActual === 'verde') {
      pitido(950, 0.06);                                     // agudo y rápido: cruce
      if (quedan <= 0) {
        luzActual = 'amarillo';
        quedan = CONFIG.SEMAFORO.amarillo;
        hablar('Amarillo. Termine de cruzar.', true);
      }
    } else {
      pitido(700, 0.07);
      if (quedan <= 0) {
        luzActual = 'rojo';
        quedan = CONFIG.SEMAFORO.rojo;
        hablar('Rojo otra vez. Espere ' + quedan + ' segundos.', true);
      }
    }

    pintarSemaforo();
  }, 1000);
}

function detenerSemaforo(){
  if (relojSemaforo) { clearInterval(relojSemaforo); relojSemaforo = null; }
}


/* ── 3. PINTAR LA PANTALLA ────────────────────────────────  */

function pintarSemaforo(){
  var roja     = document.getElementById('luzRoja');
  var amarilla = document.getElementById('luzAmarilla');
  var verde    = document.getElementById('luzVerde');
  if (!roja) return;

  // classList.toggle enciende o apaga una clase según el segundo argumento
  roja.classList.toggle('encendida',     luzActual === 'rojo');
  amarilla.classList.toggle('encendida', luzActual === 'amarillo');
  verde.classList.toggle('encendida',    luzActual === 'verde');

  var textos = {
    rojo:     { arriba:'Verde en',      color:'var(--rojo)' },
    verde:    { arriba:'Cruce ahora',   color:'var(--verde)' },
    amarillo: { arriba:'Termine de cruzar', color:'var(--amarillo)' }
  };

  var estadoEl = document.getElementById('estadoSemaforo');
  var cuentaEl = document.getElementById('cuentaAtras');

  estadoEl.textContent = textos[luzActual].arriba;
  cuentaEl.textContent = Math.max(0, quedan) + (quedan === 1 ? ' segundo' : ' segundos');
  estadoEl.style.color = textos[luzActual].color;
  cuentaEl.style.color = textos[luzActual].color;

  // Y la tarjeta del mapa también se entera
  if (luzActual === 'rojo') {
    ponerTexto('insSecundaria', 'Semáforo en ' + quedan + ' segundos cambia a verde.');
  }
}

/* El botón «Reproducir audio» de la pantalla 3 */
function leerSemaforo(){
  var frases = {
    rojo:     'Semáforo en rojo. No cruce. Faltan ' + quedan + ' segundos para el verde.',
    verde:    'Semáforo en verde. Puede cruzar. Le quedan ' + quedan + ' segundos.',
    amarillo: 'Semáforo en amarillo. Termine de cruzar, quedan ' + quedan + ' segundos.'
  };
  hablar(frases[luzActual], true);
}
